# Minesweeper
Simple beauty minesweeper game on Java :)

## Screenshots
![img0](https://user-images.githubusercontent.com/14110170/75064690-ffa88900-5519-11ea-9629-b7e7cdd5aaf2.png)
![img3](https://user-images.githubusercontent.com/14110170/75064873-531ad700-551a-11ea-866f-f291ad2972ac.png)
![img6](https://user-images.githubusercontent.com/14110170/75065235-0a175280-551b-11ea-90e4-0f2c15af246b.png)

![img1](https://user-images.githubusercontent.com/14110170/75064841-40a09d80-551a-11ea-8c16-1ee02faecac9.png)

![img2](https://user-images.githubusercontent.com/14110170/75064858-47c7ab80-551a-11ea-9301-4f22d62f028c.png)
![img5](https://user-images.githubusercontent.com/14110170/75065025-95dcaf00-551a-11ea-9c1c-7ebf1ca58b37.png)

![img7](https://user-images.githubusercontent.com/14110170/75065306-2ca96b80-551b-11ea-9943-79539a7648cb.png)
